# 🌿 Bonsai: Grow or Die

A browser-based idle business sim where you ARE Bonsai Cultivation — a scrappy Denver wholesale cannabis grow fighting to survive Colorado's legal market from Day 1 of rec legalization in 2014 all the way to April 20, 2026.

**Real P&L. Real Colorado AMR data. Real Denver wage inflation. Real prize.**

## Quick Start

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Deploy to Vercel

```bash
# Option 1: Vercel CLI
npm i -g vercel
vercel

# Option 2: Connect GitHub repo to vercel.com
# Push to GitHub → Import in Vercel dashboard → Auto-deploys on push
```

## Tech Stack

- **Next.js 15** (App Router, Turbopack)
- **TypeScript**
- **Tailwind CSS v4**
- **localStorage** for game state persistence (Supabase planned for V2)
- **Vercel** for deployment

## Game Mechanics

- **Idle timer engine** — Real-time, runs while browser is closed. 1 game month = 2 real hours.
- **Veg/Flower room system** — 32-day veg → flip → 64-day flower → harvest
- **Real AMR price data** — Colorado quarterly wholesale bud prices, 2014–2026
- **Denver wage inflation** — Labor costs scale historically, making upgrades existential
- **6 upgrade tracks** — Lighting, Irrigation, Environmental, Genetics, Pre-Roll, Operations
- **9 unlockable rooms** — Escalating costs, player chooses veg or flower
- **Vulture Capital** — Emergency bailout with permanent consequences
- **Win condition** — Cash positive on 4/20/2026 with 4+ active rooms

## Built By

Bonsai Cultivation, Denver, Colorado — the people who actually did it.

*Find your ZEN. Happy People = Happy Plants.*
