"use client";

import dynamic from "next/dynamic";

// Dynamic import with no SSR — game uses localStorage and Date.now()
const BonsaiGame = dynamic(() => import("@/components/BonsaiGame"), {
  ssr: false,
  loading: () => (
    <div
      style={{
        minHeight: "100vh",
        background: "#0a0a0a",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <div style={{ textAlign: "center" }}>
        <div
          style={{
            fontSize: 48,
            marginBottom: 16,
            animation: "pulse 1.5s ease-in-out infinite",
          }}
        >
          🌿
        </div>
        <div style={{ color: "#8BC34A", fontSize: 14, letterSpacing: 2 }}>
          LOADING...
        </div>
        <style>{`@keyframes pulse { 0%,100%{opacity:0.4;transform:scale(1)} 50%{opacity:1;transform:scale(1.1)} }`}</style>
      </div>
    </div>
  ),
});

export default function Home() {
  return <BonsaiGame />;
}
