"use client";

import React, { createContext, useContext, useState } from "react";
import type { GameState } from "@/lib/types";

interface GameContextValue {
  state: GameState | null;
  setState: React.Dispatch<React.SetStateAction<GameState | null>>;
  screen: string;
  setScreen: (s: string) => void;
  selectedRoom: number | null;
  setSelectedRoom: (i: number | null) => void;
  activeTab: string;
  setActiveTab: (t: string) => void;
  showVC: boolean;
  setShowVC: (v: boolean) => void;
  showEvent: string | null;
  setShowEvent: (id: string | null) => void;
  nameInput: string;
  setNameInput: (n: string) => void;
  roomTypeChoice: "veg" | "flower" | null;
  setRoomTypeChoice: (t: "veg" | "flower" | null) => void;
  showRoomBuy: number | null;
  setShowRoomBuy: (i: number | null) => void;
  showResetConfirm: boolean;
  setShowResetConfirm: (v: boolean) => void;
  showAMRInfo: boolean;
  setShowAMRInfo: (v: boolean) => void;
  gameSpeed: number;
  setGameSpeed: (s: number) => void;
  paused: boolean;
  setPaused: (p: boolean) => void;
  showAchievement: string | null;
  setShowAchievement: (id: string | null) => void;
}

const GameContext = createContext<GameContextValue | null>(null);

export function GameProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<GameState | null>(null);
  const [screen, setScreen] = useState("loading");
  const [selectedRoom, setSelectedRoom] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState("facility");
  const [showVC, setShowVC] = useState(false);
  const [showEvent, setShowEvent] = useState<string | null>(null);
  const [nameInput, setNameInput] = useState("");
  const [roomTypeChoice, setRoomTypeChoice] = useState<"veg" | "flower" | null>(null);
  const [showRoomBuy, setShowRoomBuy] = useState<number | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showAMRInfo, setShowAMRInfo] = useState(false);
  const [gameSpeed, setGameSpeed] = useState(1);
  const [paused, setPaused] = useState(false);
  const [showAchievement, setShowAchievement] = useState<string | null>(null);

  return (
    <GameContext.Provider
      value={{
        state, setState,
        screen, setScreen,
        selectedRoom, setSelectedRoom,
        activeTab, setActiveTab,
        showVC, setShowVC,
        showEvent, setShowEvent,
        nameInput, setNameInput,
        roomTypeChoice, setRoomTypeChoice,
        showRoomBuy, setShowRoomBuy,
        showResetConfirm, setShowResetConfirm,
        showAMRInfo, setShowAMRInfo,
        gameSpeed, setGameSpeed,
        paused, setPaused,
        showAchievement, setShowAchievement,
      }}
    >
      {children}
    </GameContext.Provider>
  );
}

export function useGame(): GameContextValue {
  const ctx = useContext(GameContext);
  if (!ctx) throw new Error("useGame must be used inside GameProvider");
  return ctx;
}
