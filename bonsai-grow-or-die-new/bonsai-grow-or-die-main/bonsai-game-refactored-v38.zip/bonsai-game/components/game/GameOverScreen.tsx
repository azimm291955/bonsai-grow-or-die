"use client";

import { useGame } from "@/context/GameContext";
import { useGameEngine } from "@/hooks/useGameEngine";
import { formatCash, formatDate, msToGameDate } from "@/lib/helpers";
import { MS_PER_GAME_DAY } from "@/lib/constants";

export default function GameOverScreen() {
  const { state } = useGame();
  const { resetGame } = useGameEngine();

  if (!state) return null;

  const totalRealMs = Date.now() - state.gameStartRealMs;
  const totalGameDays = (totalRealMs / MS_PER_GAME_DAY) + (state.bonusGameDays || 0);
  const gd = msToGameDate(totalGameDays * MS_PER_GAME_DAY);

  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(135deg, #1a1a1a 0%, #3a1a1a 50%, #1a1a1a 100%)",
      display: "flex", alignItems: "center", justifyContent: "center",
      fontFamily: "'Inter', system-ui, sans-serif",
    }}>
      <div style={{ textAlign: "center", maxWidth: 480, padding: 32 }}>
        <div style={{ marginBottom: 16 }}>
          <img
            src="/bonsai-logo.png"
            alt="Bonsai"
            style={{ width: 140, height: 140, objectFit: "contain", filter: "grayscale(100%) brightness(0.4)" }}
          />
        </div>
        <h1 style={{ color: "#ef5350", fontSize: 36, fontWeight: 700 }}>GAME OVER</h1>
        <p style={{ color: "#888", fontSize: 13, letterSpacing: 4, marginTop: 8 }}>GROW OR DIE</p>
        <div style={{ background: "#2a2a2a", borderRadius: 8, padding: 20, margin: "24px 0", border: "1px solid #ef5350" }}>
          <p style={{ color: "#ef5350", fontSize: 14, margin: 0 }}>CAUSE OF DEATH</p>
          <p style={{ color: "#fff", fontSize: 18, margin: "8px 0" }}>{state.deathCause || "Cash hit $0"}</p>
        </div>
        <p style={{ color: "#aaa", fontSize: 13 }}>
          Made it to: {formatDate(gd)} · Cash: {formatCash(state.cash)} · Rooms: {state.rooms.filter(r => r.unlocked).length}
        </p>
        <button
          onClick={resetGame}
          style={{
            marginTop: 24, padding: "14px 32px", background: "#ef5350", color: "#fff",
            border: "none", borderRadius: 8, cursor: "pointer", fontSize: 16, fontWeight: 700,
          }}
        >
          Try Again
        </button>
      </div>
    </div>
  );
}
