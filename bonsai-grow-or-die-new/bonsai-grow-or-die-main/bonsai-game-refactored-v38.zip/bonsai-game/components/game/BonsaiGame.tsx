"use client";

import Image from "next/image";
import { GameProvider, useGame } from "@/context/GameContext";
import { useGameEngine } from "@/hooks/useGameEngine";
import { useLeaderboard } from "@/hooks/useLeaderboard";
import { ACHIEVEMENTS, BASE_YIELD_PER_HARVEST } from "@/lib/constants";
import {
  msToGameDate, getQuarter, getAMR, getAverageOverheadPerRoom,
  getTotalPrerollRevenue, formatCash, formatDate, getYieldMultiplierForRoom,
  getPriceMultiplierForRoom, getMonthlyOverheadForRoom, getFlowerDaysForRoom,
  getVegDaysForRoom, getRotQuality, getRotSpeedMultiplierForRoom,
} from "@/lib/helpers";

// Sub-components
import Onboarding from "./Onboarding";
import WinScreen from "./WinScreen";
import GameOverScreen from "./GameOverScreen";
import RoomCard from "./RoomCard";
import UpgradesPanel from "./UpgradesPanel";
import PnLTab from "./PnLTab";
import AchievementsTab from "./AchievementsTab";
import LeaderboardTab from "./LeaderboardTab";
import VcOfferModal from "./modals/VcOfferModal";
import EventModal from "./modals/EventModal";
import RoomBuyModal from "./modals/RoomBuyModal";
import ResetConfirmModal from "./modals/ResetConfirmModal";
import AchievementToast from "./modals/AchievementToast";

// ─── Global keyframe styles (injected once) ──────────────────────────────────
const GAME_STYLES = `
  @keyframes action-pulse { 0%,100%{opacity:0.8;box-shadow:0 0 8px rgba(255,183,77,0.2)} 50%{opacity:1;box-shadow:0 0 20px rgba(255,183,77,0.4)} }
  @keyframes glow-green { 0%,100%{box-shadow:inset 0 0 15px rgba(139,195,74,0.05)} 50%{box-shadow:inset 0 0 25px rgba(139,195,74,0.12)} }
  @keyframes glow-purple { 0%,100%{box-shadow:inset 0 0 15px rgba(206,147,216,0.05)} 50%{box-shadow:inset 0 0 25px rgba(206,147,216,0.12)} }
  @keyframes toast-in { 0%{transform:translateY(20px);opacity:0} 100%{transform:translateY(0);opacity:1} }
  @keyframes shimmer-bar { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
  @keyframes lock-breathe { 0%,100%{border-color:rgba(255,255,255,0.04)} 50%{border-color:rgba(255,255,255,0.08)} }
  @keyframes fade-up { 0%{transform:translateY(20px);opacity:0} 100%{transform:translateY(0);opacity:1} }
`;

// ─── Main game UI (uses context directly — no prop drilling) ─────────────────
function MainGameUI() {
  const {
    state, setState,
    activeTab, setActiveTab,
    selectedRoom, setSelectedRoom,
    showAMRInfo, setShowAMRInfo,
    setShowResetConfirm,
    gameSpeed, setGameSpeed,
    paused, setPaused,
  } = useGame();
  const { flipToFlower, harvest } = useGameEngine();
  const { fetchLeaderboard } = useLeaderboard();

  if (!state) return null;

  const gd = msToGameDate(state.lastTickRealMs);
  const quarter = getQuarter(gd.month);
  const currentAMR = getAMR(gd.year, quarter);
  const overhead = getAverageOverheadPerRoom(gd.year, state.upgrades, state.rooms);
  const activeRoomCount = state.rooms.filter(r => r.unlocked).length;
  const flowerRoomCount = state.rooms.filter(r => r.unlocked && r.type === "flower").length;
  const vegRoomCount = state.rooms.filter(r => r.unlocked && r.type === "veg").length;
  const actionRooms = state.rooms.filter(r => r.unlocked && (r.status === "ready_to_flip" || r.status === "ready_to_harvest"));
  const emptyVegRooms = state.rooms.filter(r => r.unlocked && r.type === "veg" && r.status === "empty");
  const grossBurn = overhead ? overhead.total * activeRoomCount : 0;
  const prerollIncome = getTotalPrerollRevenue(state.upgrades, state.rooms) * (1 - state.vcRevenuePenalty);
  const netBurn = grossBurn - prerollIncome;
  const monthsRunway = netBurn > 0 && state.cash > 0 ? Math.floor(state.cash / netBurn) : null;

  const tabs = [
    { id: "facility", icon: "🌿", label: "Grow" },
    { id: "pnl", icon: "📊", label: "P&L" },
    { id: "upgrades", icon: "⚡", label: "Upgrades" },
    { id: "trophies", icon: "🏆", label: `${Object.keys(state.achievements || {}).length}/${ACHIEVEMENTS.length}` },
    { id: "leaderboard", icon: "👑", label: "Top 420" },
  ];

  return (
    <div
      className="min-h-screen text-white max-w-[480px] mx-auto relative"
      style={{
        background: "radial-gradient(ellipse at 50% 0%, #152015 0%, #111 30%, #0a0a0a 100%)",
        fontFamily: "'Inter', system-ui, sans-serif",
      }}
    >
      <style>{GAME_STYLES}</style>

      {/* ═══ TOP BAR ═══ */}
      <div
        className="sticky top-0 z-50 px-4 pt-2.5 pb-2"
        style={{
          background: "linear-gradient(180deg, rgba(15,20,15,0.98) 0%, rgba(10,10,10,0.95) 100%)",
          backdropFilter: "blur(12px)",
          borderBottom: "1px solid rgba(139,195,74,0.1)",
        }}
      >
        {/* Row 1: Logo + Name + Cash + Reset */}
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Image src="/bonsai-logo.png" alt="Bonsai" width={24} height={24} className="object-contain" />
            <span className="text-[#555] text-[10px]">·</span>
            <span className="text-[#777] text-[11px] font-medium">{state.playerName}</span>
            <span className="text-[#444] text-[9px] font-medium bg-white/[0.04] px-1.5 py-0.5 rounded">
              {formatDate(gd)}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <div
              className="font-extrabold text-[22px] tracking-tight"
              style={{
                color: state.cash > 0 ? "#8BC34A" : "#ef5350",
                textShadow: state.cash > 0 ? "0 0 20px rgba(139,195,74,0.2)" : "0 0 20px rgba(239,83,80,0.3)",
              }}
            >
              {formatCash(state.cash)}
            </div>
            <button
              onClick={() => setShowResetConfirm(true)}
              className="bg-white/[0.04] border border-white/[0.06] text-[#444] text-sm rounded-md px-2 py-0.5 cursor-pointer"
              title="Reset game"
              aria-label="Reset game"
            >
              ↺
            </button>
          </div>
        </div>

        {/* Row 2: Ticker strip */}
        <div className="flex gap-3 mt-2 overflow-hidden py-1">
          {[
            { label: "AMR", value: `$${currentAMR}`, color: "#FFB74D", clickable: true },
            { label: "Burn", value: `${formatCash(netBurn)}/mo`, color: netBurn > 0 ? "#ef5350" : "#8BC34A" },
            { label: "Rooms", value: `${activeRoomCount}`, sub: `${vegRoomCount}V/${flowerRoomCount}F`, color: "#888" },
            ...(monthsRunway !== null ? [{ label: "Runway", value: `${monthsRunway}mo`, color: monthsRunway < 6 ? "#ef5350" : monthsRunway < 12 ? "#FFB74D" : "#8BC34A" }] : []),
            ...(state.vcTaken ? [{ label: "VC", value: "-15%", color: "#ef5350" }] : []),
          ].map((item, idx) => (
            <div
              key={idx}
              onClick={item.clickable ? () => setShowAMRInfo(true) : undefined}
              className={`flex items-center gap-1 whitespace-nowrap ${item.clickable ? "cursor-pointer" : ""}`}
            >
              <span className="text-[9px] text-[#555] font-semibold tracking-wide">{item.label}</span>
              <span className="text-[11px] font-bold" style={{ color: item.color }}>{item.value}</span>
              {item.clickable && <span className="text-[9px] text-[#666] ml-px">ⓘ</span>}
              {item.sub && <span className="text-[9px] text-[#444]">{item.sub}</span>}
            </div>
          ))}
        </div>

        {/* Row 3: Speed controls */}
        <div className="flex items-center gap-1.5 mt-1">
          <button
            onClick={() => {
              if (paused) setState(prev => prev ? ({ ...prev, lastTickRealMs: Date.now() }) : prev);
              setPaused(p => !p);
            }}
            className="px-2.5 py-0.5 text-[10px] font-bold rounded cursor-pointer transition-all"
            style={{
              background: paused ? "rgba(139,195,74,0.12)" : "rgba(255,255,255,0.02)",
              border: paused ? "1px solid rgba(139,195,74,0.4)" : "1px solid rgba(255,255,255,0.06)",
              color: paused ? "#8BC34A" : "#666",
            }}
            title={paused ? "Resume" : "Pause"}
          >
            {paused ? "▶" : "⏸"}
          </button>
          {[1, 32, 64].map(s => (
            <button
              key={s}
              onClick={() => {
                setGameSpeed(s);
                if (paused) setState(prev => prev ? ({ ...prev, lastTickRealMs: Date.now() }) : prev);
                setPaused(false);
              }}
              className="px-2.5 py-0.5 text-[10px] font-bold rounded cursor-pointer transition-all"
              style={{
                border: !paused && gameSpeed === s ? "1px solid rgba(139,195,74,0.4)" : "1px solid rgba(255,255,255,0.06)",
                background: !paused && gameSpeed === s ? "rgba(139,195,74,0.12)" : "rgba(255,255,255,0.02)",
                color: !paused && gameSpeed === s ? "#8BC34A" : "#444",
              }}
            >
              {s}×
            </button>
          ))}
          {!paused && gameSpeed > 1 && (
            <span className="text-[9px] text-bonsai-green ml-1 opacity-60">⚡ {gameSpeed}× speed</span>
          )}
        </div>
      </div>

      {/* ═══ TAB NAV ═══ */}
      <div
        className="flex sticky z-40"
        style={{ top: 95, background: "rgba(10,10,10,0.9)", backdropFilter: "blur(8px)", borderBottom: "1px solid rgba(255,255,255,0.04)" }}
      >
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => { setActiveTab(tab.id); if (tab.id === "leaderboard") fetchLeaderboard(); }}
            className="flex-1 py-3 pb-2.5 bg-transparent border-none cursor-pointer text-[12px] font-bold tracking-widest transition-all"
            style={{
              color: activeTab === tab.id ? "#8BC34A" : "#444",
              borderBottom: activeTab === tab.id ? "2px solid #8BC34A" : "2px solid transparent",
            }}
            aria-selected={activeTab === tab.id}
            role="tab"
          >
            <span className="text-sm">{tab.icon}</span>{" "}
            <span className="text-[11px]">{tab.label.toUpperCase()}</span>
          </button>
        ))}
      </div>

      {/* ═══ CONTENT ═══ */}
      <div className="px-3 pb-20 pt-3">

        {/* ── FACILITY TAB ── */}
        {activeTab === "facility" && (
          <div>
            {/* Action banner */}
            {actionRooms.length > 0 && (
              <div className="mb-3">
                {actionRooms.map(room => (
                  <button
                    key={room.index}
                    onClick={() => setSelectedRoom(room.index)}
                    className="w-full mb-1.5 px-4 py-3 rounded-xl cursor-pointer flex justify-between items-center"
                    style={{
                      background: room.status === "ready_to_harvest"
                        ? "linear-gradient(135deg, rgba(255,183,77,0.15) 0%, rgba(255,152,0,0.08) 100%)"
                        : "linear-gradient(135deg, rgba(139,195,74,0.15) 0%, rgba(104,159,56,0.08) 100%)",
                      border: `1px solid ${room.status === "ready_to_harvest" ? "rgba(255,183,77,0.3)" : "rgba(139,195,74,0.3)"}`,
                      animation: "action-pulse 2s ease-in-out infinite",
                    }}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="text-xl">{room.status === "ready_to_harvest" ? "🌿" : "⚡"}</span>
                      <div className="text-left">
                        <div
                          className="text-sm font-bold"
                          style={{ color: room.status === "ready_to_harvest" ? "#FFB74D" : "#8BC34A" }}
                        >
                          {room.status === "ready_to_harvest" ? "HARVEST READY" : "FLIP DAY"}
                        </div>
                        <div className="text-[#666] text-[10px]">
                          Room {room.index + 1} · {room.type === "veg"
                            ? "Veg complete"
                            : `${Math.round(BASE_YIELD_PER_HARVEST * getYieldMultiplierForRoom(state.upgrades, room.index))} lbs ready`}
                        </div>
                      </div>
                    </div>
                    <div
                      className="text-[11px] font-bold tracking-widest bg-black/30 px-3 py-1 rounded-md"
                      style={{ color: room.status === "ready_to_harvest" ? "#FFB74D" : "#8BC34A" }}
                    >
                      TAP →
                    </div>
                  </button>
                ))}
              </div>
            )}

            {/* Empty veg reminder */}
            {emptyVegRooms.length > 0 && actionRooms.length === 0 && (
              <button
                onClick={() => setSelectedRoom(emptyVegRooms[0].index)}
                className="w-full mb-3 px-4 py-2.5 bg-bonsai-green/[0.06] border border-bonsai-green/[0.15] rounded-[10px] cursor-pointer flex items-center gap-2.5"
              >
                <span className="text-base">🌱</span>
                <span className="text-bonsai-green text-xs font-semibold">
                  Room {emptyVegRooms[0].index + 1} is empty — tap to start growing
                </span>
              </button>
            )}

            {/* Room grid */}
            <div className="grid gap-2.5" style={{ gridTemplateColumns: "repeat(2, 1fr)" }}>
              {state.rooms.map((room, i) => (
                <RoomCard key={i} room={room} roomIndex={i} />
              ))}
            </div>

            {/* Notification toasts */}
            {state.notifications.filter(n => n.type === "harvest").slice(-2).map((n, i) => (
              <div
                key={i}
                className="bg-bonsai-green/10 border border-bonsai-green/20 rounded-[10px] px-3.5 py-2.5 mt-2 text-xs text-bonsai-green font-medium"
                style={{ animation: "toast-in 0.3s ease-out" }}
              >
                💰 {n.message}
              </div>
            ))}
            {state.notifications.filter(n => n.type === "milestone").slice(-1).map((n, i) => (
              <div
                key={`ms-${i}`}
                className="rounded-xl px-4 py-3.5 mt-2.5"
                style={{ background: "linear-gradient(135deg,rgba(255,183,77,0.12),rgba(255,152,0,0.06))", border: "1px solid rgba(255,183,77,0.3)", animation: "toast-in 0.4s ease-out" }}
              >
                <div className="text-sm text-bonsai-amber font-bold mb-1">{n.message?.split("—")[0]}</div>
                {n.message?.includes("—") && (
                  <div className="text-[11px] text-[#999] leading-relaxed">{n.message.split("—").slice(1).join("—").trim()}</div>
                )}
              </div>
            ))}
            {state.notifications.filter(n => n.type === "rot_warning").slice(-2).map((n, i) => (
              <div key={`rot-${i}`} className="rounded-[10px] px-3.5 py-2.5 mt-2 text-xs text-bonsai-amber font-medium" style={{ background: "linear-gradient(135deg,rgba(255,183,77,0.12),rgba(239,83,80,0.06))", border: "1px solid rgba(255,183,77,0.25)", animation: "toast-in 0.3s ease-out" }}>
                {n.message}
              </div>
            ))}
            {state.notifications.filter(n => n.type === "rot_destroyed").slice(-2).map((n, i) => (
              <div key={`dead-${i}`} className="rounded-[10px] px-3.5 py-3 mt-2 text-xs text-bonsai-red font-semibold" style={{ background: "linear-gradient(135deg,rgba(239,83,80,0.15),rgba(183,28,28,0.08))", border: "1px solid rgba(239,83,80,0.3)", animation: "toast-in 0.3s ease-out" }}>
                {n.message}
              </div>
            ))}

            {/* Stats ticker */}
            <div className="flex justify-around mt-3.5 py-2.5 border-t border-b border-white/[0.04]">
              {[
                { label: "OVERHEAD", value: overhead ? formatCash(overhead.total * activeRoomCount) : "--", sub: overhead ? `${formatCash(overhead.total)}/room` : "", color: "#ef5350" },
                {
                  label: "YIELD",
                  value: (() => { const fr = state.rooms.find(r => r.unlocked && r.type === "flower"); return fr ? `${Math.round(BASE_YIELD_PER_HARVEST * getYieldMultiplierForRoom(state.upgrades, fr.index))} lbs` : "--"; })(),
                  sub: (() => { const fr = state.rooms.find(r => r.unlocked && r.type === "flower"); return fr ? `@ ${formatCash(currentAMR * getPriceMultiplierForRoom(state.upgrades, fr.index))}/lb` : ""; })(),
                  color: "#8BC34A",
                },
                {
                  label: "COST/LB",
                  value: (() => {
                    if (!overhead || flowerRoomCount === 0) return "--";
                    let totalOH = 0, totalYield = 0;
                    for (const r of state.rooms) {
                      if (r.unlocked) totalOH += getMonthlyOverheadForRoom(gd.year, state.upgrades, r.index).total;
                      if (r.unlocked && r.type === "flower") totalYield += BASE_YIELD_PER_HARVEST * getYieldMultiplierForRoom(state.upgrades, r.index);
                    }
                    return totalYield > 0 ? formatCash((totalOH * 3) / totalYield) : "--";
                  })(),
                  sub: "target",
                  color: "#FFB74D",
                },
              ].map((stat, idx) => (
                <div key={idx} className="text-center">
                  <div className="text-[8px] text-[#444] font-semibold tracking-widest mb-0.5">{stat.label}</div>
                  <div className="text-base font-extrabold" style={{ color: stat.color }}>{stat.value}</div>
                  <div className="text-[9px] text-[#333] mt-0.5">{stat.sub}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "pnl" && <PnLTab />}
        {activeTab === "upgrades" && <UpgradesPanel />}
        {activeTab === "trophies" && <AchievementsTab />}
        {activeTab === "leaderboard" && <LeaderboardTab />}
      </div>

      {/* ═══ MODALS ═══ */}
      <VcOfferModal />
      <EventModal />
      <RoomBuyModal />
      <ResetConfirmModal />
      <AchievementToast />

      {/* Room Detail Modal */}
      {selectedRoom !== null && state.rooms[selectedRoom]?.unlocked && (() => {
        const room = state.rooms[selectedRoom];
        const isVeg = room.type === "veg";
        const targetDays = isVeg ? getVegDaysForRoom(state.upgrades, selectedRoom) : getFlowerDaysForRoom(state.upgrades, selectedRoom);
        const rotQuality = getRotQuality(room.rotDays || 0, getRotSpeedMultiplierForRoom(state.upgrades, selectedRoom));

        return (
          <div
            className="fixed inset-0 bg-black/85 z-[100] flex items-end justify-center"
            onClick={e => { if (e.target === e.currentTarget) setSelectedRoom(null); }}
          >
            <div className="bg-[#222] rounded-t-2xl w-full max-w-[480px] p-6 max-h-[70vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-4">
                <h2 className="m-0 text-xl font-bold">
                  Room {selectedRoom + 1}
                  <span className={`text-xs ml-2 font-semibold ${isVeg ? "text-bonsai-green" : "text-bonsai-purple"}`}>
                    {isVeg ? "VEG" : "FLOWER"}
                  </span>
                </h2>
                <button onClick={() => setSelectedRoom(null)} className="bg-transparent border-none text-[#666] text-2xl cursor-pointer">×</button>
              </div>

              <p className="text-sm text-[#888] mb-3">
                Status: <strong className="text-white">
                  {room.status === "empty" ? "Empty" :
                   room.status === "growing" ? `Growing — ${Math.floor(room.daysGrown)}/${targetDays} days` :
                   room.status === "ready_to_flip" ? "⚡ Ready to Flip!" :
                   room.status === "ready_to_harvest" ? "🌿 Ready to Harvest!" : room.status}
                </strong>
              </p>

              {room.status === "growing" && (
                <div className="w-full h-2 bg-[#333] rounded mb-2">
                  <div
                    className="h-full rounded transition-all duration-1000"
                    style={{
                      width: `${Math.min(room.daysGrown / targetDays, 1) * 100}%`,
                      background: isVeg ? "#8BC34A" : "#CE93D8",
                    }}
                  />
                </div>
              )}

              {rotQuality < 1 && (room.status === "ready_to_flip" || room.status === "ready_to_harvest") && (
                <div className="text-[11px] font-bold mb-3" style={{ color: rotQuality < 0.3 ? "#ef5350" : "#FFB74D" }}>
                  ⚠️ Quality: {Math.round(rotQuality * 100)}% — {room.status === "ready_to_harvest" ? "Harvest" : "Flip"} soon!
                </div>
              )}

              {/* Action buttons */}
              <div className="flex flex-col gap-2 mt-4">
                {room.status === "empty" && isVeg && (
                  <button
                    onClick={() => { setState(prev => { if (!prev) return prev; const ns = JSON.parse(JSON.stringify(prev)); ns.rooms[selectedRoom].status = "growing"; ns.rooms[selectedRoom].daysGrown = 0; ns.rooms[selectedRoom].growStartMs = Date.now(); return ns; }); setSelectedRoom(null); }}
                    className="w-full py-3 bg-bonsai-green/20 border border-bonsai-green/40 rounded-xl text-bonsai-green font-bold text-sm cursor-pointer hover:bg-bonsai-green/30 transition-colors"
                  >
                    🌱 Start Growing
                  </button>
                )}
                {room.status === "ready_to_flip" && (
                  <button
                    onClick={() => { flipToFlower(selectedRoom); setSelectedRoom(null); }}
                    className="w-full py-3 bg-bonsai-amber/20 border border-bonsai-amber/40 rounded-xl text-bonsai-amber font-bold text-sm cursor-pointer hover:bg-bonsai-amber/30 transition-colors"
                  >
                    ⚡ Flip to Flower
                  </button>
                )}
                {room.status === "ready_to_harvest" && (
                  <button
                    onClick={() => { harvest(selectedRoom); setSelectedRoom(null); }}
                    className="w-full py-3 bg-bonsai-green/20 border border-bonsai-green/40 rounded-xl text-bonsai-green font-bold text-sm cursor-pointer hover:bg-bonsai-green/30 transition-colors"
                  >
                    🌿 Harvest Room
                  </button>
                )}
                <button
                  onClick={() => setSelectedRoom(null)}
                  className="w-full py-2 bg-white/[0.03] border border-white/[0.06] rounded-xl text-[#666] text-sm cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* AMR Info Modal */}
      {showAMRInfo && (
        <div className="fixed inset-0 bg-black/85 z-[200] flex items-center justify-center" onClick={() => setShowAMRInfo(false)}>
          <div className="bg-[#1a1a1a] border border-bonsai-amber/20 rounded-2xl p-6 max-w-sm mx-4" onClick={e => e.stopPropagation()}>
            <div className="text-base font-extrabold text-bonsai-amber mb-2 tracking-widest">AVERAGE MARKET RATE (AMR)</div>
            <p className="text-xs text-[#888] leading-relaxed mb-4">
              The AMR is the wholesale price per pound your broker pays. It tracks real Colorado cannabis market data from 2015–2026.
              Prices peaked in 2017 (~$1,400/lb), crashed by 2019, and have continued to compress.
              Upgrades can raise your effective sell price above the AMR.
            </p>
            <div className="text-sm font-bold text-bonsai-amber mb-3">Current: ${currentAMR}/lb</div>
            <button onClick={() => setShowAMRInfo(false)} className="w-full py-2 bg-white/[0.05] border border-white/[0.08] rounded-lg text-[#666] text-sm cursor-pointer">Got it</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Router — picks which screen to show ─────────────────────────────────────
function GameRouter() {
  const { screen, state } = useGame();
  useGameEngine(); // mounts tick loop

  if (screen === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a]">
        <div className="text-bonsai-green text-sm">Loading…</div>
      </div>
    );
  }
  if (screen === "onboarding") return <Onboarding />;
  if (state?.gameWon) return <WinScreen />;
  if (state?.gameOver) return <GameOverScreen />;
  return <MainGameUI />;
}

// ─── Root export — wraps everything in context ────────────────────────────────
export default function BonsaiGame() {
  return (
    <GameProvider>
      <GameRouter />
    </GameProvider>
  );
}
