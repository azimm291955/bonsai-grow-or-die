import { Redis } from "@upstash/redis";
import { NextRequest, NextResponse } from "next/server";

// Initialize Redis using Vercel-connected env vars
const redis = new Redis({
  url: process.env.KV_REST_API_URL!,
  token: process.env.KV_REST_API_TOKEN!,
});

// --- Score signing ---
const SALT_PREFIX = "bonsai_grow_or_die_2026_";
const SALT_SUFFIX = "_420_leaderboard";

function getSigningSalt(): string {
  const envSalt = process.env.LEADERBOARD_SIGNING_SECRET || "zen_happy_plants";
  return SALT_PREFIX + envSalt + SALT_SUFFIX;
}

async function computeHash(data: string): Promise<string> {
  const encoder = new TextEncoder();
  const keyData = encoder.encode(getSigningSalt());
  const msgData = encoder.encode(data);

  const cryptoKey = await crypto.subtle.importKey(
    "raw", keyData, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const signature = await crypto.subtle.sign("HMAC", cryptoKey, msgData);
  const hashArray = Array.from(new Uint8Array(signature));
  return hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
}

async function verifyScore(
  playerName: string,
  finalCash: number,
  rooms: number,
  totalHarvests: number,
  signature: string
): Promise<boolean> {
  const payload = `${playerName}|${Math.round(finalCash)}|${rooms}|${totalHarvests}`;
  const expected = await computeHash(payload);
  return expected === signature;
}

const KV_KEY = "leaderboard:top420";
const MAX_ENTRIES = 420;

// Hardcoded AZ seed entry
const AZ_SEED = {
  playerName: "AZ",
  finalCash: 69000000,
  rooms: 9,
  totalHarvests: 99,
  submittedAt: "2026-04-20T04:20:00.000Z",
};

interface LeaderboardResult {
  rank: number;
  name: string;
  cash: number;
  rooms: number;
  harvests: number;
  ts: number;
}

// --- GET: Fetch top 420 ---
export async function GET() {
  try {
    // Upstash zrange with rev + withScores returns { score, member } objects
    const raw = await redis.zrange(KV_KEY, 0, MAX_ENTRIES - 1, { rev: true, withScores: true });

    const results: LeaderboardResult[] = [];

    for (let i = 0; i < raw.length; i++) {
      const entry = raw[i] as unknown;

      if (typeof entry === "number") continue;

      let memberData: Record<string, unknown>;
      let cash: number;

      if (
        typeof entry === "object" &&
        entry !== null &&
        "score" in (entry as object) &&
        "member" in (entry as object)
      ) {
        const e = entry as { score: number; member: unknown };
        memberData = e.member as Record<string, unknown>;
        cash = e.score;
      } else if (typeof entry === "object" && entry !== null) {
        memberData = entry as Record<string, unknown>;
        cash =
          i + 1 < raw.length && typeof raw[i + 1] === "number"
            ? (raw[i + 1] as number)
            : 0;
      } else if (typeof entry === "string") {
        try {
          memberData = JSON.parse(entry);
        } catch {
          continue;
        }
        cash =
          i + 1 < raw.length && typeof raw[i + 1] === "number"
            ? (raw[i + 1] as number)
            : 0;
      } else {
        continue;
      }

      if (typeof memberData === "string") {
        try {
          memberData = JSON.parse(memberData);
        } catch {
          continue;
        }
      }

      if (memberData && typeof memberData === "object") {
        results.push({
          rank: results.length + 1,
          name: (memberData.name as string) || "???",
          cash: Math.round(cash),
          rooms: (memberData.rooms as number) || 0,
          harvests: (memberData.harvests as number) || 0,
          ts: (memberData.ts as number) || 0,
        });
      }
    }

    // Merge AZ seed entry if not already present
    const azAlreadyExists = results.some(
      e => e.name === AZ_SEED.playerName && e.cash === AZ_SEED.finalCash
    );
    if (!azAlreadyExists) {
      const azEntry: LeaderboardResult = {
        rank: 0, // will be recalculated
        name: AZ_SEED.playerName,
        cash: AZ_SEED.finalCash,
        rooms: AZ_SEED.rooms,
        harvests: AZ_SEED.totalHarvests,
        ts: new Date(AZ_SEED.submittedAt).getTime(),
      };
      // Insert at correct position (sorted by cash desc)
      const insertIdx = results.findIndex(e => e.cash < AZ_SEED.finalCash);
      if (insertIdx === -1) {
        results.push(azEntry);
      } else {
        results.splice(insertIdx, 0, azEntry);
      }
    }

    // Re-number ranks
    results.forEach((e, i) => { e.rank = i + 1; });

    return NextResponse.json({ entries: results, total: results.length });
  } catch (error) {
    console.error("Leaderboard GET error:", error);
    return NextResponse.json(
      { entries: [], total: 0, error: "Failed to fetch leaderboard" },
      { status: 500 }
    );
  }
}

// --- POST: Submit score ---
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { playerName, finalCash, rooms, totalHarvests, signature } = body as {
      playerName: string;
      finalCash: number;
      rooms: number;
      totalHarvests: number;
      signature: string;
    };

    if (!playerName || typeof finalCash !== "number" || typeof rooms !== "number" || !signature) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }
    if (finalCash <= 0) {
      return NextResponse.json({ error: "Cash must be positive to be on leaderboard" }, { status: 400 });
    }
    if (rooms < 4) {
      return NextResponse.json({ error: "Need at least 4 rooms to qualify" }, { status: 400 });
    }
    if (finalCash > 500000000) {
      return NextResponse.json({ error: "Cash amount exceeds maximum possible" }, { status: 400 });
    }
    if (playerName.length > 24) {
      return NextResponse.json({ error: "Name too long" }, { status: 400 });
    }

    const valid = await verifyScore(playerName, finalCash, rooms, totalHarvests, signature);
    if (!valid) {
      return NextResponse.json({ error: "Invalid score signature" }, { status: 403 });
    }

    const member = JSON.stringify({
      name: playerName.slice(0, 24),
      rooms,
      harvests: totalHarvests,
      ts: Date.now(),
    });

    await redis.zadd(KV_KEY, { score: Math.round(finalCash), member });

    const totalEntries = await redis.zcard(KV_KEY);
    if (totalEntries > MAX_ENTRIES) {
      await redis.zremrangebyrank(KV_KEY, 0, totalEntries - MAX_ENTRIES - 1);
    }

    const rank = await redis.zrevrank(KV_KEY, member);

    return NextResponse.json({
      success: true,
      rank: rank !== null ? rank + 1 : null,
      message:
        rank !== null && rank < MAX_ENTRIES
          ? `You're #${rank + 1} on the leaderboard!`
          : "Score submitted but didn't make top 420",
    });
  } catch (error) {
    console.error("Leaderboard POST error:", error);
    return NextResponse.json({ error: "Failed to submit score" }, { status: 500 });
  }
}
