"use client";

import { useEffect, useRef, useCallback } from "react";
import { useGame } from "@/context/GameContext";
import { useAchievements } from "@/hooks/useAchievements";
import type { GameState } from "@/lib/types";
import {
  ROOM_COSTS, UPGRADE_TRACKS, VEG_DAYS, FLOWER_DAYS,
  MS_PER_GAME_DAY, GAME_START_DATE,
} from "@/lib/constants";
import {
  createInitialState, migrateUpgrades, msToGameDate, getQuarter,
  getAMR, getVegDaysForRoom, getFlowerDaysForRoom, getMonthlyOverheadForRoom,
  getTotalPrerollRevenue, hasAutoFlipForRoom, getRotSpeedMultiplierForRoom,
  getRotQuality, getYieldMultiplierForRoom, getPriceMultiplierForRoom,
  getVegQualityBonus, getRoomUpgradeTier, getUpgradeCostForRoom, formatCash,
} from "@/lib/helpers";
import {
  EXCISE_TAX_RATE, BROKER_FEE_RATE, COVID_DEMAND_MOD,
  BASE_YIELD_PER_HARVEST,
} from "@/lib/constants";

// ---- localStorage persistence ----
const STORAGE_KEY = "bonsai_grow_or_die";

function saveToStorage(s: GameState) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(s)); } catch { /* noop */ }
}

function loadFromStorage(): GameState | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* noop */ }
  return null;
}

export function useGameEngine() {
  const {
    state, setState,
    screen, setScreen,
    gameSpeed,
    paused,
    setShowVC, showVC,
    setShowEvent,
    setSelectedRoom,
    setShowRoomBuy,
    setRoomTypeChoice,
    roomTypeChoice,
    nameInput,
    setActiveTab,
    setNameInput,
    setShowResetConfirm,
    setShowAchievement,
    showAchievement,
  } = useGame();

  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const { checkAchievements, processAchievementQueue, achievementQueueRef } = useAchievements();

  // ---- Init: load saved game ----
  useEffect(() => {
    const saved = loadFromStorage();
    if (saved && saved.playerName) {
      if (saved.upgrades) {
        saved.upgrades = migrateUpgrades(saved.upgrades, saved.rooms || []);
      }
      // Ensure all fields exist for old saves
      if (!saved.achievements) saved.achievements = {};
      if (!saved.achievementProgress) saved.achievementProgress = {};
      if (!saved.roomsHarvested) saved.roomsHarvested = {};
      if (saved.totalSpentOnUpgrades === undefined) saved.totalSpentOnUpgrades = 0;
      if (saved.consecutiveProfitMonths === undefined) saved.consecutiveProfitMonths = 0;
      if (saved.hadCropRot === undefined) saved.hadCropRot = false;
      if (saved.totalLbsProduced === undefined) saved.totalLbsProduced = 0;
      if (saved.peakCash === undefined) saved.peakCash = saved.cash || 0;
      if (saved.lowestCash === undefined) saved.lowestCash = saved.cash || 0;
      if (saved.totalWholesaleRevenue === undefined) saved.totalWholesaleRevenue = 0;
      if (saved.totalPrerollRevenue === undefined) saved.totalPrerollRevenue = 0;
      if (saved.totalSpentOnRooms === undefined) saved.totalSpentOnRooms = 0;
      if (saved.vcTriggered === undefined) saved.vcTriggered = false;
      setState(saved);
      setScreen("game");
    } else {
      setScreen("onboarding");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---- Process achievement popup queue ----
  useEffect(() => {
    processAchievementQueue(showAchievement);
  }, [showAchievement, state, processAchievementQueue]);

  // ---- Process notifications (VC trigger, events) ----
  useEffect(() => {
    if (!state?.notifications?.length) return;
    const vcNotif = state.notifications.find(n => n.type === "vc_trigger");
    if (vcNotif && !showVC) {
      setShowVC(true);
      setState(prev => prev ? ({
        ...prev,
        notifications: prev.notifications.filter(n => n.type !== "vc_trigger"),
      }) : prev);
    }
    const eventNotif = state.notifications.find(n => n.type === "event");
    if (eventNotif && !showVC) {
      setShowEvent(eventNotif.id ?? null);
      setState(prev => prev ? ({
        ...prev,
        notifications: prev.notifications.filter(n => n !== eventNotif),
      }) : prev);
    }
  }, [state?.notifications, showVC, setShowVC, setShowEvent, setState]);

  // ---- Game tick ----
  const processTick = useCallback(() => {
    setState(prev => {
      if (!prev || prev.gameOver || prev.gameWon) return prev;

      const now = Date.now();
      const rawElapsedMs = now - prev.lastTickRealMs;
      const maxTickMs = 30000;
      const elapsedMs = Math.min(rawElapsedMs, maxTickMs);
      const baseGameDays = elapsedMs / MS_PER_GAME_DAY;

      if (baseGameDays <= 0) return prev;

      const newState: GameState = JSON.parse(JSON.stringify(prev));
      newState.lastTickRealMs = now;

      const effectiveGameDays = baseGameDays * gameSpeed;
      const bonusDays = baseGameDays * (gameSpeed - 1);
      newState.bonusGameDays = (newState.bonusGameDays || 0) + bonusDays;

      const totalRealMs = now - newState.gameStartRealMs;
      const totalGameDays = (totalRealMs / MS_PER_GAME_DAY) + (newState.bonusGameDays || 0);
      const gd = msToGameDate(totalGameDays * MS_PER_GAME_DAY);

      // Win condition
      if (gd.year > 2026 || (gd.year === 2026 && gd.month >= 4 && gd.day >= 20)) {
        const activeRooms = newState.rooms.filter(r => r.unlocked).length;
        if (newState.cash > 0 && activeRooms >= 4) {
          newState.gameWon = true;
          newState.winType = newState.vcTaken ? "vc" : "pure";
          saveToStorage(newState);
          return newState;
        } else if (gd.year > 2026 || (gd.year === 2026 && gd.month > 4)) {
          newState.gameOver = true;
          newState.deathCause = newState.cash <= 0 ? "Ran out of cash" : "Not enough active rooms (need 4+)";
          saveToStorage(newState);
          return newState;
        }
      }

      // Process rooms
      for (const room of newState.rooms) {
        if (!room.unlocked) continue;
        const rotSpeed = getRotSpeedMultiplierForRoom(newState.upgrades, room.index);

        if (room.status === "growing") {
          room.daysGrown += effectiveGameDays;
          room.rotDays = 0;
          const targetDays = room.type === "veg"
            ? getVegDaysForRoom(newState.upgrades, room.index)
            : getFlowerDaysForRoom(newState.upgrades, room.index);

          if (room.daysGrown >= targetDays) {
            if (room.type === "veg") {
              if (hasAutoFlipForRoom(newState.upgrades, room.index)) {
                const availFlower = newState.rooms.find(r =>
                  r.unlocked && r.type === "flower" && r.status === "empty" && r.harvestCount > 0
                );
                if (availFlower) {
                  availFlower.status = "growing";
                  availFlower.daysGrown = 0;
                  availFlower.growStartMs = now;
                  room.status = "growing";
                  room.daysGrown = 0;
                  room.growStartMs = now;
                  continue;
                }
              }
              room.status = "ready_to_flip";
              room.stalled = true;
              room.rotDays = 0;
            } else {
              room.status = "ready_to_harvest";
              room.rotDays = 0;
            }
          }
        }

        if (room.status === "ready_to_flip" || room.status === "ready_to_harvest") {
          room.rotDays += effectiveGameDays;
          const quality = getRotQuality(room.rotDays, rotSpeed);

          if (quality <= 0.5 && quality > 0.45 && !room._rot50warned) {
            room._rot50warned = true;
            newState.notifications.push({
              type: "rot_warning",
              message: `⚠️ Room ${room.index + 1} quality dropping — ${room.status === "ready_to_harvest" ? "harvest" : "flip"} soon! (${Math.round(quality * 100)}%)`,
            });
          }
          if (quality <= 0.25 && quality > 0.2 && !room._rot25warned) {
            room._rot25warned = true;
            newState.notifications.push({
              type: "rot_warning",
              message: `🚨 Room ${room.index + 1} CRITICAL — quality at ${Math.round(quality * 100)}%! Act now or lose the crop!`,
            });
          }

          if (quality <= 0) {
            room.status = "empty";
            room.daysGrown = 0;
            room.growStartMs = null;
            room.rotDays = 0;
            room._rot50warned = false;
            room._rot25warned = false;
            newState.hadCropRot = true;
            newState._achCropDeath = true;
            newState.notifications.push({
              type: "rot_destroyed",
              message: `💀 Room ${room.index + 1} crop DESTROYED — plants died from neglect.`,
            });
          }
        }

        if (room.status !== "ready_to_flip" && room.status !== "ready_to_harvest") {
          room._rot50warned = false;
          room._rot25warned = false;
        }
      }

      // Monthly overhead
      const currentMonth = (gd.year - GAME_START_DATE.year) * 12 + gd.month;
      if (currentMonth > newState.lastProcessedMonth) {
        const monthsToProcess = Math.min(currentMonth - newState.lastProcessedMonth, 12);

        for (let m = 0; m < monthsToProcess; m++) {
          const processMonth = newState.lastProcessedMonth + m + 1;
          const pYear = GAME_START_DATE.year + Math.floor((processMonth - 1) / 12);
          const pMonth = ((processMonth - 1) % 12) + 1;

          let totalOverhead = 0;
          for (const r of newState.rooms) {
            if (r.unlocked) totalOverhead += getMonthlyOverheadForRoom(pYear, newState.upgrades, r.index).total;
          }

          if (newState.vcOverheadCredit > 0) {
            totalOverhead *= (1 - newState.vcOverheadCredit);
          }

          const prerollRev = getTotalPrerollRevenue(newState.upgrades, newState.rooms);
          const effectivePreroll = prerollRev * (1 - newState.vcRevenuePenalty);

          newState.cash -= totalOverhead;
          newState.cash += effectivePreroll;
          newState.totalCosts += totalOverhead;
          newState.totalRevenue += effectivePreroll;
          newState.totalPrerollRevenue = (newState.totalPrerollRevenue || 0) + effectivePreroll;

          if (newState.cash > (newState.peakCash || 0)) newState.peakCash = newState.cash;
          if (newState.cash < (newState.lowestCash ?? newState.cash)) newState.lowestCash = newState.cash;

          if (newState.monthlyPnL.length > 200) newState.monthlyPnL.shift();
          const monthNet = effectivePreroll - totalOverhead;
          newState.monthlyPnL.push({
            year: pYear, month: pMonth, overhead: totalOverhead,
            preroll: effectivePreroll, harvestRevenue: 0, net: monthNet, cash: newState.cash,
          });

          if (monthNet < 0) {
            newState._achRedMonth = true;
            newState.consecutiveProfitMonths = 0;
          } else {
            newState.consecutiveProfitMonths = (newState.consecutiveProfitMonths || 0) + 1;
          }
        }
        newState.lastProcessedMonth = currentMonth;
      }

      // Narrative events
      const quarter = getQuarter(gd.month);
      const eventChecks = [
        { year: 2018, quarter: 0, id: "crash2018" },
        { year: 2020, quarter: 0, id: "covid2020" },
        { year: 2022, quarter: 0, id: "cliff2022" },
      ];
      for (const ec of eventChecks) {
        if (gd.year === ec.year && quarter >= ec.quarter && !newState.eventsShown[ec.id]) {
          newState.eventsShown[ec.id] = true;
          newState.notifications.push({ type: "event", id: ec.id });
        }
      }

      // VC trigger
      if (newState.cash <= 0 && !newState.vcTaken && !newState.gameOver && !newState.vcTriggered) {
        newState.vcTriggered = true;
        newState.notifications.push({ type: "vc_trigger" });
      } else if (newState.cash <= 0 && newState.vcTaken) {
        newState.gameOver = true;
        newState.deathCause = "Second bankruptcy. Vulture Capital already used.";
      }

      const tickExtras = {
        redMonth: newState._achRedMonth,
        cropDeath: newState._achCropDeath,
      };
      newState._achRedMonth = false;
      newState._achCropDeath = false;
      checkAchievements(newState, gd, tickExtras);

      saveToStorage(newState);
      return newState;
    });
  }, [setState, gameSpeed, checkAchievements]);

  // ---- Interval ----
  useEffect(() => {
    if (screen === "game" && !paused && (!state || state.tutorialStep === 0 || state.tutorialStep >= 5)) {
      const interval = gameSpeed >= 64 ? 150 : gameSpeed >= 32 ? 300 : 2000;
      tickRef.current = setInterval(processTick, interval);
      return () => {
        if (tickRef.current) clearInterval(tickRef.current);
      };
    }
    if (tickRef.current) clearInterval(tickRef.current);
  }, [screen, paused, processTick, state?.tutorialStep, gameSpeed]);

  // ---- Action handlers ----

  const startGame = useCallback(() => {
    if (!nameInput.trim()) return;
    const initial = createInitialState(nameInput.trim());
    initial.rooms[0].status = "ready_to_flip";
    initial.rooms[0].growStartMs = Date.now();
    initial.rooms[0].daysGrown = VEG_DAYS;
    initial.rooms[0].stalled = true;
    initial.tutorialStep = 1;
    setState(initial);
    saveToStorage(initial);
    setScreen("game");
  }, [nameInput, setState, setScreen]);

  const unlockRoom = useCallback((index: number) => {
    setState(prev => {
      if (!prev) return prev;
      const ns: GameState = JSON.parse(JSON.stringify(prev));
      const cost = ROOM_COSTS[index];
      if (ns.cash < cost) return prev;
      ns.cash -= cost;
      ns.totalSpentOnRooms = (ns.totalSpentOnRooms || 0) + cost;
      ns.rooms[index].unlocked = true;
      ns.rooms[index].type = index === 1 ? "flower" : roomTypeChoice;
      ns.rooms[index].status = "empty";
      saveToStorage(ns);
      return ns;
    });
    setShowRoomBuy(null);
    setRoomTypeChoice(null);
  }, [setState, roomTypeChoice, setShowRoomBuy, setRoomTypeChoice]);

  const flipToFlower = useCallback((vegIndex: number, flowerIndex: number) => {
    setState(prev => {
      if (!prev) return prev;
      const ns: GameState = JSON.parse(JSON.stringify(prev));
      const veg = ns.rooms[vegIndex];
      const flower = ns.rooms[flowerIndex];
      if (!veg || !flower) return prev;

      const rawVegQuality = getRotQuality(veg.rotDays, getRotSpeedMultiplierForRoom(ns.upgrades, vegIndex));
      const vegBonus = getVegQualityBonus(ns.upgrades, vegIndex);
      const vegQuality = Math.min(rawVegQuality * (1 + vegBonus), 1 + vegBonus);

      flower.status = "growing";
      flower.daysGrown = 0;
      flower.growStartMs = Date.now();
      flower.vegQuality = vegQuality;
      flower.rotDays = 0;
      veg.status = "growing";
      veg.daysGrown = 0;
      veg.growStartMs = Date.now();
      veg.stalled = false;
      veg.rotDays = 0;

      const totalRealMs = Date.now() - ns.gameStartRealMs;
      const totalGameMs = totalRealMs + (ns.bonusGameDays || 0) * MS_PER_GAME_DAY;
      checkAchievements(ns, msToGameDate(totalGameMs), {});

      saveToStorage(ns);
      return ns;
    });
    setSelectedRoom(null);
  }, [setState, checkAchievements, setSelectedRoom]);

  const harvest = useCallback((index: number) => {
    setState(prev => {
      if (!prev) return prev;
      const ns: GameState = JSON.parse(JSON.stringify(prev));
      const room = ns.rooms[index];
      if (room.status !== "ready_to_harvest") return prev;

      const totalRealMs = Date.now() - ns.gameStartRealMs;
      const totalGameMs = totalRealMs + (ns.bonusGameDays || 0) * MS_PER_GAME_DAY;
      const gd = msToGameDate(totalGameMs);
      const quarter = getQuarter(gd.month);
      const amr = getAMR(gd.year, quarter);
      const yieldMult = getYieldMultiplierForRoom(ns.upgrades, index);
      const priceMult = getPriceMultiplierForRoom(ns.upgrades, index);

      const rawVegQ = room.vegQuality || 1.0;
      const softenedVegQ = rawVegQ >= 1.0 ? rawVegQ : Math.max(0.85, 1.0 - (1.0 - rawVegQ) * 0.45);

      const lbs = Math.round(BASE_YIELD_PER_HARVEST * yieldMult * softenedVegQ);
      let salePrice = amr * priceMult;

      const rawRotQ = getRotQuality(room.rotDays, getRotSpeedMultiplierForRoom(ns.upgrades, index));
      const softenedRotQ = rawRotQ >= 1.0 ? 1.0 : 1.0 - (1.0 - rawRotQ) * 0.45;
      salePrice *= softenedRotQ;

      const covidMod = (COVID_DEMAND_MOD as Record<number, number[]>)[gd.year];
      if (covidMod) salePrice *= covidMod[quarter];

      const grossRevenue = lbs * salePrice;
      const excise = grossRevenue * EXCISE_TAX_RATE;
      const broker = grossRevenue * BROKER_FEE_RATE;
      const netRevenue = grossRevenue - excise - broker;
      const effectiveRevenue = netRevenue * (1 - ns.vcRevenuePenalty);

      ns.cash += effectiveRevenue;
      ns.totalRevenue += effectiveRevenue;
      ns.totalLbsProduced = (ns.totalLbsProduced || 0) + lbs;
      ns.totalWholesaleRevenue = (ns.totalWholesaleRevenue || 0) + effectiveRevenue;

      if (ns.cash > (ns.peakCash || 0)) ns.peakCash = ns.cash;
      if (ns.cash < (ns.lowestCash ?? ns.cash)) ns.lowestCash = ns.cash;

      room.status = "empty";
      room.daysGrown = 0;
      room.growStartMs = null;
      room.rotDays = 0;
      room.harvestCount += 1;

      // Auto-flip
      if (room.type === "flower" && room.harvestCount > 0) {
        const waitingVeg = ns.rooms.find(r =>
          r.unlocked && r.type === "veg" && r.status === "ready_to_flip" &&
          hasAutoFlipForRoom(ns.upgrades, r.index)
        );
        if (waitingVeg) {
          const rawVegQ2 = getRotQuality(waitingVeg.rotDays || 0, getRotSpeedMultiplierForRoom(ns.upgrades, waitingVeg.index));
          const autoVegBonus = getVegQualityBonus(ns.upgrades, waitingVeg.index);
          const vegQ2 = Math.min(rawVegQ2 * (1 + autoVegBonus), 1 + autoVegBonus);
          room.status = "growing";
          room.daysGrown = 0;
          room.growStartMs = Date.now();
          room.vegQuality = vegQ2;
          room.rotDays = 0;
          waitingVeg.status = "growing";
          waitingVeg.daysGrown = 0;
          waitingVeg.growStartMs = Date.now();
          waitingVeg.stalled = false;
          waitingVeg.rotDays = 0;
          ns.notifications.push({
            type: "harvest",
            message: `⚡ Auto-flip: Room ${waitingVeg.index + 1} veg → Room ${room.index + 1} flower`,
          });
        }
      }

      if (ns.monthlyPnL.length > 0) {
        ns.monthlyPnL[ns.monthlyPnL.length - 1].harvestRevenue += effectiveRevenue;
        ns.monthlyPnL[ns.monthlyPnL.length - 1].net += effectiveRevenue;
        ns.monthlyPnL[ns.monthlyPnL.length - 1].cash = ns.cash;
      }

      const rotPenaltyMsg = softenedRotQ < 1.0 ? ` (${Math.round(softenedRotQ * 100)}% quality)` : "";
      ns.notifications.push({
        type: "harvest",
        message: `Harvested ${lbs} lbs @ ${formatCash(salePrice)}/lb = ${formatCash(effectiveRevenue)} net${rotPenaltyMsg}`,
      });

      if (!ns.roomsHarvested) ns.roomsHarvested = {};
      ns.roomsHarvested[index] = true;

      const achieveExtras = {
        megaHarvest: effectiveRevenue >= 500000,
      };
      checkAchievements(ns, gd, achieveExtras);
      saveToStorage(ns);
      return ns;
    });
  }, [setState, checkAchievements]);

  const buyUpgrade = useCallback((track: string, tierIndex: number, roomIndex: number) => {
    setState(prev => {
      if (!prev) return prev;
      const ns: GameState = JSON.parse(JSON.stringify(prev));
      const tier = UPGRADE_TRACKS[track].tiers[tierIndex];
      const scaledCost = getUpgradeCostForRoom(track, tierIndex, ns.upgrades);
      if (ns.cash < scaledCost) return prev;
      const currentRoomTier = getRoomUpgradeTier(ns.upgrades, track, roomIndex);
      if (currentRoomTier !== tierIndex) return prev;
      if (!ns.rooms[roomIndex]?.unlocked) return prev;

      if (tier.yearGate) {
        const totalRealMs = Date.now() - ns.gameStartRealMs;
        const totalGameMs = totalRealMs + (ns.bonusGameDays || 0) * MS_PER_GAME_DAY;
        const gd = msToGameDate(totalGameMs);
        if (gd.year < tier.yearGate) return prev;
      }

      ns.cash -= scaledCost;
      ns.totalSpentOnUpgrades = (ns.totalSpentOnUpgrades || 0) + scaledCost;
      if (!ns.upgrades[track]) ns.upgrades[track] = {};
      ns.upgrades[track][roomIndex] = tierIndex + 1;

      const totalRealMs2 = Date.now() - ns.gameStartRealMs;
      const totalGameMs2 = totalRealMs2 + (ns.bonusGameDays || 0) * MS_PER_GAME_DAY;
      const gd2 = msToGameDate(totalGameMs2);
      checkAchievements(ns, gd2, {});

      saveToStorage(ns);
      return ns;
    });
  }, [setState, checkAchievements]);

  const acceptVC = useCallback(() => {
    setState(prev => {
      if (!prev) return prev;
      const ns: GameState = JSON.parse(JSON.stringify(prev));
      const activeRooms = ns.rooms.filter(r => r.unlocked);
      const roomsToLose = Math.floor(activeRooms.length / 2);

      const totalRealMs = Date.now() - ns.gameStartRealMs;
      const totalGameMs = totalRealMs + (ns.bonusGameDays || 0) * MS_PER_GAME_DAY;
      const gd = msToGameDate(totalGameMs);
      let totalMonthlyOverhead = 0;
      for (const r of activeRooms) {
        totalMonthlyOverhead += getMonthlyOverheadForRoom(gd.year, ns.upgrades, r.index).total;
      }
      const injection = totalMonthlyOverhead * 3;

      let lost = 0;
      for (let i = 8; i >= 2 && lost < roomsToLose; i--) {
        if (ns.rooms[i].unlocked) {
          ns.rooms[i].unlocked = false;
          ns.rooms[i].status = "empty";
          ns.rooms[i].type = null;
          ns.rooms[i].daysGrown = 0;
          ns.rooms[i].growStartMs = null;
          lost++;
        }
      }

      ns.cash = injection;
      ns.vcTaken = true;
      ns.vcRevenuePenalty = 0.15;
      ns.vcOverheadCredit = 0.05;
      ns.notifications = [];

      saveToStorage(ns);
      return ns;
    });
    setShowVC(false);
  }, [setState, setShowVC]);

  const declineVC = useCallback(() => {
    setState(prev => {
      if (!prev) return prev;
      const ns: GameState = JSON.parse(JSON.stringify(prev));
      ns.gameOver = true;
      ns.deathCause = "Declined Vulture Capital. Cash hit $0.";
      saveToStorage(ns);
      return ns;
    });
    setShowVC(false);
  }, [setState, setShowVC]);

  const resetGame = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    setState(null);
    setScreen("onboarding");
    setActiveTab("facility");
    setNameInput("");
    setShowVC(false);
    setShowEvent(null);
    setShowAchievement(null);
    setSelectedRoom(null);
    setShowRoomBuy(null);
    setShowResetConfirm(false);
    achievementQueueRef.current = [];
  }, [setState, setScreen, setActiveTab, setNameInput, setShowVC, setShowEvent, setShowAchievement, setSelectedRoom, setShowRoomBuy, setShowResetConfirm, achievementQueueRef]);

  const advanceTutorial = useCallback((toStep: number) => {
    setState(prev => {
      if (!prev) return prev;
      const ns: GameState = JSON.parse(JSON.stringify(prev));
      ns.tutorialStep = toStep;

      if (toStep === 5) {
        ns.gameStartRealMs = Date.now();
        ns.lastTickRealMs = Date.now();
        ns.bonusGameDays = 0;
        ns.rooms[0].status = "growing";
        ns.rooms[0].daysGrown = 0;
        ns.rooms[0].growStartMs = Date.now();
        ns.rooms[0].stalled = false;
        if (ns.rooms[1].status === "growing") {
          ns.rooms[1].daysGrown = 0;
          ns.rooms[1].growStartMs = Date.now();
        }
      }

      saveToStorage(ns);
      return ns;
    });
  }, [setState]);

  const tutorialBuyRoom2 = useCallback(() => {
    setState(prev => {
      if (!prev) return prev;
      const ns: GameState = JSON.parse(JSON.stringify(prev));
      const cost = ROOM_COSTS[1];
      if (ns.cash < cost) return prev;
      ns.cash -= cost;
      ns.rooms[1].unlocked = true;
      ns.rooms[1].type = "flower";
      ns.rooms[1].status = "empty";
      ns.tutorialStep = 3;
      saveToStorage(ns);
      return ns;
    });
  }, [setState]);

  const tutorialFlip = useCallback(() => {
    setState(prev => {
      if (!prev) return prev;
      const ns: GameState = JSON.parse(JSON.stringify(prev));
      ns.rooms[1].status = "growing";
      ns.rooms[1].daysGrown = 0;
      ns.rooms[1].growStartMs = Date.now();
      ns.rooms[0].status = "growing";
      ns.rooms[0].daysGrown = 0;
      ns.rooms[0].growStartMs = Date.now();
      ns.rooms[0].stalled = false;
      ns.tutorialStep = 4;
      saveToStorage(ns);
      return ns;
    });
  }, [setState]);

  return {
    startGame,
    unlockRoom,
    flipToFlower,
    harvest,
    buyUpgrade,
    acceptVC,
    declineVC,
    resetGame,
    advanceTutorial,
    tutorialBuyRoom2,
    tutorialFlip,
  };
}


