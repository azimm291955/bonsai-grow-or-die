"use client";

import { useState, useCallback, useEffect } from "react";
import { useGame } from "@/context/GameContext";
import { signScore } from "@/lib/signing";

export interface LeaderboardEntry {
  rank: number;
  name: string;
  cash: number;
  rooms: number;
  harvests: number;
  ts: number;
}

export function useLeaderboard() {
  const { state, screen } = useGame();
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [leaderboardLoading, setLeaderboardLoading] = useState(false);
  const [leaderboardSubmitted, setLeaderboardSubmitted] = useState(false);
  const [leaderboardSubmitting, setLeaderboardSubmitting] = useState(false);
  const [leaderboardRank, setLeaderboardRank] = useState<number | null>(null);
  const [showLeaderboardPrompt, setShowLeaderboardPrompt] = useState(false);

  const fetchLeaderboard = useCallback(async () => {
    setLeaderboardLoading(true);
    try {
      const res = await fetch("/api/leaderboard");
      if (res.ok) {
        const data = await res.json();
        setLeaderboard(data.entries || []);
      }
    } catch (e) {
      console.error("Failed to fetch leaderboard:", e);
    }
    setLeaderboardLoading(false);
  }, []);

  const submitToLeaderboard = useCallback(async () => {
    if (!state || !state.gameWon || leaderboardSubmitted || leaderboardSubmitting) return;
    setLeaderboardSubmitting(true);
    const totalHarvests = state.rooms.reduce((s, r) => s + r.harvestCount, 0);
    const rooms = state.rooms.filter(r => r.unlocked).length;
    const finalCash = Math.round(state.cash);

    try {
      const sig = await signScore(state.playerName, finalCash, rooms, totalHarvests);
      const res = await fetch("/api/leaderboard", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          playerName: state.playerName,
          finalCash,
          rooms,
          totalHarvests,
          signature: sig,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setLeaderboardSubmitted(true);
        setLeaderboardRank(data.rank);
        fetchLeaderboard();
      } else {
        const err = await res.json().catch(() => ({}));
        alert("Failed to submit: " + (err.error || "Unknown error"));
      }
    } catch (e) {
      console.error("Failed to submit score:", e);
      alert("Network error — check your connection and try again.");
    }
    setLeaderboardSubmitting(false);
    setShowLeaderboardPrompt(false);
  }, [state, leaderboardSubmitted, leaderboardSubmitting, fetchLeaderboard]);

  // Fetch leaderboard when screen becomes "game" — FIXED: fetchLeaderboard in deps
  useEffect(() => {
    if (screen === "game") fetchLeaderboard();
  }, [screen, fetchLeaderboard]);

  return {
    leaderboard,
    leaderboardLoading,
    leaderboardSubmitted,
    leaderboardSubmitting,
    leaderboardRank,
    showLeaderboardPrompt,
    setShowLeaderboardPrompt,
    fetchLeaderboard,
    submitToLeaderboard,
  };
}
