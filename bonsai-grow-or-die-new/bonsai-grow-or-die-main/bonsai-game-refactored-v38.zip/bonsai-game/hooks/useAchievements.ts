"use client";

import { useCallback, useRef } from "react";
import { useGame } from "@/context/GameContext";
import type { GameState, GameDate } from "@/lib/types";
import { UPGRADE_TRACKS, ACHIEVEMENTS } from "@/lib/constants";
import { getRoomUpgradeTier } from "@/lib/helpers";

export function useAchievements() {
  const { setShowAchievement } = useGame();
  const achievementQueueRef = useRef<string[]>([]);

  const unlockAchievement = useCallback((ns: GameState, id: string): boolean => {
    if (!ns.achievements) ns.achievements = {};
    if (ns.achievements[id]) return false;
    ns.achievements[id] = true;
    achievementQueueRef.current.push(id);
    return true;
  }, []);

  const checkAchievements = useCallback(
    (ns: GameState, gd: GameDate, extras: Record<string, unknown>) => {
      if (!ns || ns.tutorialStep < 5) return;
      if (!ns.achievements) ns.achievements = {};
      if (!ns.achievementProgress) ns.achievementProgress = {};
      if (!ns.roomsHarvested) ns.roomsHarvested = {};

      const totalHarvests = ns.rooms.reduce((s, r) => s + r.harvestCount, 0);
      const unlockedRooms = ns.rooms.filter(r => r.unlocked);
      const unlockedCount = unlockedRooms.length;
      const nonEmptyRooms = unlockedRooms.filter(r => r.status !== "empty");
      const roomsWithHarvests = Object.keys(ns.roomsHarvested || {}).length;

      // --- CULTIVATION ---
      ns.achievementProgress.harvest_10 = totalHarvests;
      ns.achievementProgress.harvest_30 = totalHarvests;
      if (totalHarvests >= 1) unlockAchievement(ns, "first_harvest");
      if (totalHarvests >= 10) unlockAchievement(ns, "harvest_10");
      if (totalHarvests >= 30) unlockAchievement(ns, "harvest_30");

      ns.achievementProgress.assembly_line = roomsWithHarvests;
      if (roomsWithHarvests >= 5) unlockAchievement(ns, "assembly_line");

      if (extras?.cropDeath || ns.hadCropRot) unlockAchievement(ns, "crop_death");

      // --- FINANCIAL ---
      ns.achievementProgress.rev_1m = ns.totalRevenue;
      ns.achievementProgress.rev_5m = ns.totalRevenue;
      ns.achievementProgress.rev_25m = ns.totalRevenue;
      if (ns.totalRevenue >= 1000000) unlockAchievement(ns, "rev_1m");
      if (ns.totalRevenue >= 5000000) unlockAchievement(ns, "rev_5m");
      if (ns.totalRevenue >= 25000000) unlockAchievement(ns, "rev_25m");

      ns.achievementProgress.cash_hoarder = ns.cash;
      if (ns.cash >= 2000000) unlockAchievement(ns, "cash_hoarder");

      if (extras?.redMonth) unlockAchievement(ns, "red_month");

      // --- FACILITY ---
      ns.achievementProgress.rooms_4 = unlockedCount;
      ns.achievementProgress.rooms_9 = unlockedCount;
      if (unlockedCount >= 4) unlockAchievement(ns, "rooms_4");
      if (unlockedCount >= 9) unlockAchievement(ns, "rooms_9");
      if (unlockedCount >= 9 && nonEmptyRooms.length >= 9)
        unlockAchievement(ns, "all_active");

      // --- UPGRADES ---
      for (const [track, trackData] of Object.entries(UPGRADE_TRACKS)) {
        const maxTier = trackData.tiers.length;
        for (const tier of Object.values(ns.upgrades[track] || {})) {
          if ((tier as number) >= maxTier) { unlockAchievement(ns, "track_master"); break; }
        }
      }

      for (const room of unlockedRooms) {
        let allMaxed = true;
        for (const [track, trackData] of Object.entries(UPGRADE_TRACKS)) {
          if (getRoomUpgradeTier(ns.upgrades, track, room.index) < trackData.tiers.length) {
            allMaxed = false; break;
          }
        }
        if (allMaxed) { unlockAchievement(ns, "fully_loaded"); break; }
      }

      if (unlockedCount >= 2) {
        let allRoomsMaxed = true;
        for (const room of unlockedRooms) {
          for (const [track, trackData] of Object.entries(UPGRADE_TRACKS)) {
            if (getRoomUpgradeTier(ns.upgrades, track, room.index) < trackData.tiers.length) {
              allRoomsMaxed = false; break;
            }
          }
          if (!allRoomsMaxed) break;
        }
        if (allRoomsMaxed) unlockAchievement(ns, "completionist");
      }

      // --- SURVIVAL & ERAS ---
      if (gd.year >= 2018 && gd.month >= 6) unlockAchievement(ns, "crash_2018");
      if (gd.year >= 2021) unlockAchievement(ns, "covid_2020");
      if (gd.year >= 2023) unlockAchievement(ns, "cliff_2022");

      if (ns.gameWon) {
        unlockAchievement(ns, "win_game");
        if (!ns.vcTaken) unlockAchievement(ns, "pure_grower");
        if (unlockedCount === 4) unlockAchievement(ns, "minimalist");
        if (ns.hadCropRot) unlockAchievement(ns, "phoenix");
      }

      // --- CHALLENGE ---
      if (extras?.megaHarvest) unlockAchievement(ns, "mega_harvest");

      const realDaysPlayed = (Date.now() - ns.gameStartRealMs) / (1000 * 60 * 60 * 24);
      if (realDaysPlayed >= 7) unlockAchievement(ns, "patient_grower");
    },
    [unlockAchievement]
  );

  const processAchievementQueue = useCallback((showAchievement: string | null) => {
    if (showAchievement) return;
    if (achievementQueueRef.current.length > 0) {
      const nextId = achievementQueueRef.current.shift()!;
      setShowAchievement(nextId);
    }
  }, [setShowAchievement]);

  return { achievementQueueRef, unlockAchievement, checkAchievements, processAchievementQueue };
}
