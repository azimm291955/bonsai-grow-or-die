import { SIGN_SALT } from "./constants";

export async function signScore(
  playerName: string,
  finalCash: number,
  rooms: number,
  totalHarvests: number
): Promise<string> {
  const payload = `${playerName}|${Math.round(finalCash)}|${rooms}|${totalHarvests}`;
  const msg = SIGN_SALT + "|" + payload;
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(SIGN_SALT),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(msg));
  return Array.from(new Uint8Array(sig))
    .map(b => b.toString(16).padStart(2, "0"))
    .join("");
}
